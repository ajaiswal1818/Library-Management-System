﻿Public Class remove_detail


End Class
