﻿Public Class eBooks

    Private Sub Search_OnTextChange(sender As Object, e As EventArgs) Handles Search.OnTextChange

    End Sub

    Private Sub Search_Button_Click(sender As Object, e As EventArgs) Handles Search_Button.Click

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class
