﻿Public Class eBooks

    Private Sub Search_OnTextChange(sender As Object, e As EventArgs)

    End Sub

    Private Sub Search_Button_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub
End Class
